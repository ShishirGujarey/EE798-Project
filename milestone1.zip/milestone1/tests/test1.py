b:str="str"
a:float=1.01
if a<10:
  a=a+1
else:
  b="str1"
