a:int=3
b:float=0.9
c:int=4    

def sed(a:int)->int:
    d:int=1


x:int=sed(a)
y:int=sed(a*1)
z:int=sed(a+c)


