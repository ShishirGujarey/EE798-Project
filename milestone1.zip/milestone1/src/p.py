a:int=2
b:int=3
def func(a:int,b:int) -> int :
    c:int = 19+a

class sdd :
    def __init__(self):
        self.pp:int=1
        self.a:float=0.09
    def f(self,po:int):
        self.pp:int=po
        self.a:float=po

s:sdd=sdd()
d:sdd=sdd()
