#ifndef CP_H
#define CP_H
#include<bits/stdc++.h>
#include "symbol.h"
using namespace std;
class Node
{

public:
  string label;
  string value;
  // string e_label;
  vector<Node *> children;
  string type="";
  Node* parent=NULL;
  int line_no;
  symbol_table * sym_tab;
  Symbol * sym=NULL;
  vector<Symbol*> Sym_list;

};
// extern Node * root;
#endif